This is the Hello World example from the git tutorial.
(changed in original)
